uci set eibd.@eibd[0].ga_tp_policy='n'
uci set eibd.@eibd[0].ia_ip_policy='n'
uci set eibd.@eibd[0].ia_tp_policy='n'
uci set eibd.@eibd[0].ga_ip_policy='n'
uci set eibd.@eibd[0].dst_policy='n'
uci set eibd.@eibd[0].src_policy='n'
uci set eibd.@eibd[0].p2p_policy='n'
uci commit eibd
/etc/init.d/eibd restart
